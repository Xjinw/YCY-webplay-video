import {
  API_BASE,
  buildCommandMessage,
  desiredAt,
  diffActive,
  findOverlap,
  formatSeconds,
  formatTime,
  loginUserId,
  parseConnectCode,
  peerUserId,
  stopAllMessage,
  validateSegment,
} from './timeline.js';

const STORAGE_KEY = 'ycy.web.project.v1';

const DEFAULT_COMMANDS = [
  { id: 'hurt', label: '刺激', color: '#9c7cff', payload: '' },
  { id: 'miss', label: '轻刺激', color: '#4fd8c4', payload: '' },
  { id: 'bomb', label: '强刺激', color: '#ff6b7e', payload: '' },
];
const PALETTE = ['#9c7cff', '#4fd8c4', '#ffb86b', '#ff6b7e', '#5b8cff', '#7ee081', '#e08bff', '#ffd45b'];

const $ = (id) => document.getElementById(id);
const ui = {
  status: $('status'),
  connectCode: $('connectCode'),
  btnConnect: $('btnConnect'),
  connectInfo: $('connectInfo'),
  connectError: $('connectError'),
  btnCopyLink: $('btnCopyLink'),
  videoFile: $('videoFile'),
  videoName: $('videoName'),
  video: $('video'),
  videoMeta: $('videoMeta'),
  commandList: $('commandList'),
  cmdId: $('cmdId'),
  cmdLabel: $('cmdLabel'),
  btnAddCommand: $('btnAddCommand'),
  commandError: $('commandError'),
  btnAddSegment: $('btnAddSegment'),
  playheadLabel: $('playheadLabel'),
  timeline: $('timeline'),
  lead: $('lead'),
  leadValue: $('leadValue'),
  stopOnPause: $('stopOnPause'),
  endStopAll: $('endStopAll'),
  btnStopAll: $('btnStopAll'),
  btnExport: $('btnExport'),
  importFile: $('importFile'),
  log: $('log'),
  btnClearLog: $('btnClearLog'),
  editor: $('editor'),
  editorTitle: $('editorTitle'),
  segCommand: $('segCommand'),
  segStart: $('segStart'),
  segEnd: $('segEnd'),
  segPayload: $('segPayload'),
  segError: $('segError'),
  segDelete: $('segDelete'),
  segCancel: $('segCancel'),
  segSave: $('segSave'),
  toast: $('toast'),
};

const STATUS_TEXT = {
  idle: '未连接',
  connecting: '连接中…',
  ready: '已连接',
  error: '连接失败',
};

const el = { video: ui.video };

function uuid() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `s-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function emptyProject() {
  return {
    name: '未命名项目',
    videoName: '',
    durationMs: 0,
    commands: DEFAULT_COMMANDS.map((item) => ({ ...item })),
    segments: [],
    leadMs: 120,
    stopOnPause: true,
    endStopAll: false,
  };
}

function loadProject() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyProject();
    const parsed = JSON.parse(raw);
    const base = emptyProject();
    return {
      ...base,
      ...parsed,
      commands: Array.isArray(parsed.commands) && parsed.commands.length ? parsed.commands : base.commands,
      segments: Array.isArray(parsed.segments) ? parsed.segments : [],
    };
  } catch {
    return emptyProject();
  }
}

let project = loadProject();
let session = { status: 'idle', uid: null, token: null, chat: null, appid: null };
let playing = false;
let playheadMs = 0;
let prevActive = new Map();
let editingId = null;
let videoUrl = null;
let logs = [];
let sendChain = Promise.resolve();
let saveTimer = null;

function saveProject() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
    } catch (err) {
      console.warn('保存项目失败', err);
    }
  }, 250);
}

function log(message, level = 'info') {
  const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  logs.push({ time, message, level });
  if (logs.length > 120) logs.shift();
  renderLog();
}

function renderLog() {
  ui.log.replaceChildren();
  for (const item of logs.slice(-80)) {
    const li = document.createElement('li');
    li.dataset.level = item.level;
    li.textContent = `[${item.time}] ${item.message}`;
    ui.log.append(li);
  }
  ui.log.scrollTop = ui.log.scrollHeight;
}

function renderStatus() {
  ui.status.textContent = STATUS_TEXT[session.status] ?? session.status;
  ui.status.dataset.state = session.status;
}

function toast(message) {
  ui.toast.textContent = message;
  ui.toast.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => {
    ui.toast.hidden = true;
  }, 2400);
}

function showConnectError(error) {
  ui.connectError.textContent = error?.message || String(error);
  ui.connectError.hidden = false;
  session = { ...session, status: 'error' };
  renderStatus();
  log(`连接失败：${ui.connectError.textContent}`, 'error');
}

// ---------------------------------------------------------------- IM

function loginReady(chat, userID, userSig) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('等待 IM SDK_READY 超时'));
    }, 15_000);
    chat.on(TencentCloudChat.EVENT.SDK_READY, () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve();
    });
    chat.login({ userID, userSig }).catch((err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(err);
    });
  });
}

async function connect(rawCode) {
  if (!globalThis.TencentCloudChat) throw new Error('IM SDK 未加载（vendor/chat.js）');
  const { uid, token } = parseConnectCode(rawCode);
  if (session.chat) {
    try {
      await session.chat.logout();
      await session.chat.destroy();
    } catch {
      /* 忽略旧连接清理失败 */
    }
  }
  session = { status: 'connecting', uid: null, token: null, chat: null, appid: null };
  renderStatus();
  ui.connectError.hidden = true;

  const response = await fetch(`${API_BASE}/user/game_sign`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ connect_code: `${peerUserId(uid)} ${token}` }),
  });
  const payload = await response.json().catch(() => ({}));
  if (payload.code !== 1 || !payload.data?.appid || !payload.data?.sign) {
    throw new Error(payload.msg || `获取签名失败（HTTP ${response.status}）`);
  }

  const appid = Number(payload.data.appid);
  const chat = TencentCloudChat.create({ SDKAppID: appid });
  chat.setLogLevel?.(TencentCloudChat.LOG_LEVEL?.NONE ?? 4);
  await loginReady(chat, loginUserId(uid), payload.data.sign);

  session = { status: 'ready', uid, token, chat, appid };
  renderStatus();
  ui.connectInfo.hidden = false;
  ui.connectInfo.textContent =
    `uid=${peerUserId(uid)} · appid=${appid} · token=${token.slice(0, 4)}…${token.slice(-4)}`;
  log(`IM 已就绪：game_${peerUserId(uid)} → ${peerUserId(uid)}`);
}

function sendText(text) {
  if (!session.chat || session.status !== 'ready') {
    log(`未连接，丢弃指令：${text}`, 'error');
    return;
  }
  const message = session.chat.createTextMessage({
    to: peerUserId(session.uid),
    conversationType: TencentCloudChat.TYPES.CONV_C2C,
    payload: { text },
  });
  sendChain = sendChain
    .then(() => session.chat.sendMessage(message))
    .then(() => log(text, 'send'))
    .catch((err) => log(`发送失败：${err?.message || err}`, 'error'));
}

function sendStopAll(reason) {
  if (session.status !== 'ready') return;
  log(`停止全部（${reason}）`);
  sendText(stopAllMessage(session.token));
}

// ---------------------------------------------------------------- 指令

function renderCommands() {
  ui.commandList.replaceChildren();
  if (!project.commands.length) {
    const empty = document.createElement('p');
    empty.className = 'hint';
    empty.textContent = '还没有指令。先在役次元 App 里创建指令，再把指令 ID 加到这里。';
    ui.commandList.append(empty);
    return;
  }
  for (const command of project.commands) {
    const row = document.createElement('div');
    row.className = 'command-item';

    const dot = document.createElement('span');
    dot.className = 'command-dot';
    dot.style.background = command.color || '#9c7cff';

    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = command.label;

    const id = document.createElement('span');
    id.className = 'id';
    id.textContent = command.id;

    const spacer = document.createElement('span');
    spacer.className = 'spacer';

    const remove = document.createElement('button');
    remove.className = 'ghost small';
    remove.textContent = '删除';
    remove.addEventListener('click', () => {
      if (!confirm(`删除指令「${command.label}」及其片段？`)) return;
      project.commands = project.commands.filter((item) => item.id !== command.id);
      project.segments = project.segments.filter((segment) => segment.commandId !== command.id);
      saveProject();
      renderCommands();
      renderTimeline();
    });

    row.append(dot, name, id, spacer, remove);
    ui.commandList.append(row);
  }
}

function showCommandError(message) {
  ui.commandError.textContent = message;
  ui.commandError.hidden = !message;
}

function addCommand() {
  const id = ui.cmdId.value.trim();
  const label = ui.cmdLabel.value.trim();
  if (!/^[A-Za-z0-9_.:-]{1,64}$/.test(id)) {
    showCommandError('指令 ID 只能包含字母、数字、_ . : -，且不超过 64 字符');
    return;
  }
  if (project.commands.some((item) => item.id === id)) {
    showCommandError('指令 ID 已存在');
    return;
  }
  const color = PALETTE[project.commands.length % PALETTE.length];
  project.commands.push({ id, label: label || id, color, payload: '' });
  saveProject();
  renderCommands();
  renderTimeline();
  ui.cmdId.value = '';
  ui.cmdLabel.value = '';
  showCommandError('');
  log(`添加指令 ${id}`);
}

// ---------------------------------------------------------------- 时间轴

function pct(value, total) {
  return `${Math.min(100, Math.max(0, (value / total) * 100)).toFixed(3)}%`;
}

function renderTimeline() {
  ui.timeline.replaceChildren();
  const duration = project.durationMs > 0 ? project.durationMs : 60_000;
  if (!project.commands.length) {
    const empty = document.createElement('div');
    empty.className = 'timeline-empty';
    empty.textContent = '先添加指令，再排时间轴。';
    ui.timeline.append(empty);
    return;
  }
  for (const command of project.commands) {
    const row = document.createElement('div');
    row.className = 'tl-row';

    const label = document.createElement('div');
    label.className = 'tl-label';
    label.textContent = command.label;
    label.title = command.id;

    const track = document.createElement('div');
    track.className = 'tl-track';

    for (const segment of project.segments.filter((item) => item.commandId === command.id)) {
      const bar = document.createElement('div');
      bar.className = `tl-bar${segment.id === editingId ? ' selected' : ''}`;
      bar.style.left = pct(segment.startMs, duration);
      bar.style.width = pct(Math.max(0, segment.endMs - segment.startMs), duration);
      bar.style.minWidth = '3px';
      bar.style.background = command.color;
      bar.title = `${formatTime(segment.startMs)} - ${formatTime(segment.endMs)}`;
      bar.addEventListener('click', (event) => {
        event.stopPropagation();
        openEditor(segment.id);
      });
      track.append(bar);
    }

    const head = document.createElement('div');
    head.className = 'tl-playhead';
    track.append(head);

    track.addEventListener('click', (event) => {
      const rect = track.getBoundingClientRect();
      const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
      seekTo(ratio * duration);
    });

    row.append(label, track);
    ui.timeline.append(row);
  }
  updatePlayhead();
}

function updatePlayhead() {
  const duration = project.durationMs > 0 ? project.durationMs : 60_000;
  const left = pct(playheadMs, duration);
  ui.timeline.querySelectorAll('.tl-playhead').forEach((head) => {
    head.style.left = left;
  });
  ui.playheadLabel.textContent = formatTime(playheadMs);
}

function seekTo(ms) {
  const duration = project.durationMs > 0 ? project.durationMs : el.video.duration || 0;
  const target = duration > 0 ? Math.min(duration, Math.max(0, ms)) : Math.max(0, ms);
  if (Number.isFinite(el.video.duration) && el.video.duration > 0) {
    el.video.currentTime = target / 1000;
  }
  playheadMs = target;
  prevActive.clear();
  updatePlayhead();
}

// ---------------------------------------------------------------- 片段编辑

function openEditor(id) {
  if (!project.commands.length) {
    toast('请先添加指令');
    return;
  }
  editingId = id ?? null;
  const segment = id ? project.segments.find((item) => item.id === id) : null;
  const duration = project.durationMs;
  const start = segment ? segment.startMs : Math.round((el.video.currentTime || 0) * 1000);
  const fallbackEnd = duration > 0 ? Math.min(start + 5000, duration) : start + 5000;
  const end = segment ? segment.endMs : Math.max(start + 1000, fallbackEnd);

  ui.editorTitle.textContent = segment ? '编辑片段' : '添加片段';
  ui.segCommand.replaceChildren();
  for (const command of project.commands) {
    const option = document.createElement('option');
    option.value = command.id;
    option.textContent = `${command.label}（${command.id}）`;
    ui.segCommand.append(option);
  }
  ui.segCommand.value = segment?.commandId || project.commands[0].id;
  ui.segStart.value = formatSeconds(start);
  ui.segEnd.value = formatSeconds(end);
  ui.segPayload.value = segment?.payload || '';
  ui.segError.hidden = true;
  ui.segDelete.hidden = !segment;
  ui.editor.hidden = false;
}

function closeEditor() {
  ui.editor.hidden = true;
  editingId = null;
  renderTimeline();
}

function saveSegment() {
  const commandId = ui.segCommand.value;
  const startMs = Math.round(Number(ui.segStart.value) * 1000);
  const endMs = Math.round(Number(ui.segEnd.value) * 1000);
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) {
    ui.segError.textContent = '时间格式不正确';
    ui.segError.hidden = false;
    return;
  }
  const candidate = {
    id: editingId || uuid(),
    commandId,
    startMs,
    endMs,
    payload: ui.segPayload.value.trim(),
  };
  const error = validateSegment(candidate, project.durationMs);
  if (error) {
    ui.segError.textContent = error;
    ui.segError.hidden = false;
    return;
  }
  const overlap = findOverlap(project.segments, candidate);
  if (overlap) {
    ui.segError.textContent = `与同一指令的片段重叠：${formatTime(overlap.startMs)} - ${formatTime(overlap.endMs)}`;
    ui.segError.hidden = false;
    return;
  }
  project.segments = [...project.segments.filter((item) => item.id !== candidate.id), candidate].sort(
    (a, b) => a.startMs - b.startMs,
  );
  saveProject();
  log(`保存片段 ${commandId} ${formatTime(startMs)}-${formatTime(endMs)}`);
  closeEditor();
}

// ---------------------------------------------------------------- 播放联动

function parsePayload(raw) {
  const text = String(raw ?? '').trim();
  if (!text) return undefined;
  const value = JSON.parse(text);
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('payload 必须是 JSON 对象');
  }
  return value;
}

function tick() {
  updatePlayhead();
  if (!playing) return;
  const position = (el.video.currentTime || 0) * 1000;
  playheadMs = position;
  const desired = desiredAt(project.segments, position, Number(project.leadMs) || 0);
  const { started, ended } = diffActive(prevActive, desired);
  if (ended.length && project.endStopAll) sendStopAll('片段结束');
  prevActive = desired;
  for (const segment of started) {
    const command = project.commands.find((item) => item.id === segment.commandId);
    if (!command) continue;
    let payload;
    try {
      payload = parsePayload(segment.payload || command.payload);
    } catch (err) {
      log(`payload 无效，已忽略（${segment.commandId}）：${err.message}`, 'error');
    }
    sendText(buildCommandMessage({ id: segment.commandId, payload, token: session.token }));
  }
}

// ---------------------------------------------------------------- 事件绑定

ui.btnConnect.addEventListener('click', () => {
  const code = ui.connectCode.value.trim();
  if (!code) {
    showConnectError(new Error('请填写连接码'));
    return;
  }
  connect(code).catch(showConnectError);
});
ui.connectCode.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') ui.btnConnect.click();
});
ui.btnCopyLink.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(location.href);
    log('链接已复制，请粘贴到系统浏览器打开');
    toast('链接已复制');
  } catch {
    prompt('复制本页链接：', location.href);
  }
});

ui.videoFile.addEventListener('change', () => {
  const file = ui.videoFile.files?.[0];
  if (!file) return;
  if (videoUrl) URL.revokeObjectURL(videoUrl);
  videoUrl = URL.createObjectURL(file);
  el.video.src = videoUrl;
  project.videoName = file.name;
  ui.videoName.textContent = file.name;
  ui.videoMeta.textContent = '读取时长中…';
  saveProject();
});

ui.btnAddCommand.addEventListener('click', addCommand);
ui.cmdId.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') addCommand();
});

ui.btnAddSegment.addEventListener('click', () => openEditor(null));
ui.lead.addEventListener('input', () => {
  project.leadMs = Number(ui.lead.value);
  ui.leadValue.textContent = String(project.leadMs);
  saveProject();
});
ui.stopOnPause.addEventListener('change', () => {
  project.stopOnPause = ui.stopOnPause.checked;
  saveProject();
});
ui.endStopAll.addEventListener('change', () => {
  project.endStopAll = ui.endStopAll.checked;
  saveProject();
});
ui.btnStopAll.addEventListener('click', () => sendStopAll('手动'));
ui.btnClearLog.addEventListener('click', () => {
  logs = [];
  renderLog();
});

ui.segCancel.addEventListener('click', closeEditor);
ui.editor.addEventListener('click', (event) => {
  if (event.target === ui.editor) closeEditor();
});
ui.segSave.addEventListener('click', saveSegment);
ui.segDelete.addEventListener('click', () => {
  if (!editingId) return;
  project.segments = project.segments.filter((item) => item.id !== editingId);
  saveProject();
  closeEditor();
});

ui.btnExport.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'ycy-web-project.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 2000);
});
ui.importFile.addEventListener('change', async () => {
  const file = ui.importFile.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    if (!Array.isArray(parsed.commands) || !Array.isArray(parsed.segments)) {
      throw new Error('项目文件缺少 commands / segments');
    }
    project = { ...emptyProject(), ...parsed };
    saveProject();
    renderCommands();
    renderTimeline();
    syncSettingsUi();
    log(`已导入项目：${project.name}`);
  } catch (err) {
    log(`导入失败：${err.message}`, 'error');
  }
});

el.video.addEventListener('loadedmetadata', () => {
  project.durationMs = Math.round((el.video.duration || 0) * 1000);
  ui.videoMeta.textContent = `时长 ${formatTime(project.durationMs)} · ${project.videoName || '本地视频'}`;
  saveProject();
  renderTimeline();
});
el.video.addEventListener('play', () => {
  playing = true;
  prevActive.clear();
  log('开始播放');
});
el.video.addEventListener('pause', () => {
  playing = false;
  prevActive.clear();
  if (project.stopOnPause) sendStopAll('暂停');
});
el.video.addEventListener('seeked', () => {
  prevActive.clear();
});
el.video.addEventListener('timeupdate', () => {
  playheadMs = (el.video.currentTime || 0) * 1000;
  updatePlayhead();
});

function syncSettingsUi() {
  ui.lead.value = String(project.leadMs);
  ui.leadValue.textContent = String(project.leadMs);
  ui.stopOnPause.checked = Boolean(project.stopOnPause);
  ui.endStopAll.checked = Boolean(project.endStopAll);
}

// ---------------------------------------------------------------- 启动

function init() {
  renderStatus();
  renderCommands();
  renderTimeline();
  syncSettingsUi();
  ui.videoName.textContent = project.videoName || '未选择';
  ui.videoMeta.textContent = project.videoName
    ? `上次使用：${project.videoName}，请重新选择文件`
    : '—';
  log('网页版已加载。从役次元 App 启动会自动连接。');
  setInterval(tick, 40);

  const params = new URLSearchParams(location.search);
  const code = params.get('connect_code');
  const uid = params.get('uid');
  const token = params.get('token');
  const auto = code || (uid && token ? `${uid} ${token}` : '');
  if (auto) {
    ui.connectCode.value = auto.trim();
    connect(auto.trim()).catch(showConnectError);
  }
}

init();
