/**
 * 纯逻辑：连接码解析、指令消息、时间轴求值与切换。
 * 同时被浏览器（ES module）和 Node 测试使用。
 */

export const API_BASE = 'https://suo.jiushu1234.com/api.php';

export function parseConnectCode(input) {
  const raw = String(input ?? '')
    .replace(/\u3000/g, ' ')
    .trim();
  if (!raw) throw new Error('连接码为空');
  const parts = raw.split(/\s+/);
  if (parts.length < 2) throw new Error('连接码格式应为「UID 空格 Token」');
  const uid = parts[0];
  const token = parts.slice(1).join('');
  if (!uid || !token) throw new Error('连接码缺少 UID 或 Token');
  return { uid, token };
}

/** IM 登录 userID 必须带 game_ 前缀 */
export function loginUserId(uid) {
  const value = String(uid ?? '').trim();
  if (!value) throw new Error('uid 为空');
  return value.startsWith('game_') ? value : `game_${value}`;
}

/** 发消息的 to 用裸 uid */
export function peerUserId(uid) {
  return String(uid ?? '').trim().replace(/^game_/, '');
}

/**
 * 构造 game_cmd 消息（JSON 字符串，放进 IM 的 payload.text）。
 * payload 仅电击器会用到，可缺省。
 */
export function buildCommandMessage({ id, payload, token }) {
  const commandId = String(id ?? '').trim();
  if (!commandId) throw new Error('指令 ID 为空');
  const body = { code: 'game_cmd', id: commandId };
  if (payload && typeof payload === 'object' && Object.keys(payload).length > 0) {
    body.payload = payload;
  }
  if (token) body.token = token;
  return JSON.stringify(body);
}

export function stopAllMessage(token) {
  return JSON.stringify(
    token ? { code: 'game_cmd', id: '_stop_all', token } : { code: 'game_cmd', id: '_stop_all' },
  );
}

/**
 * 某一时刻每个指令应运行哪个片段：同一指令重叠时取开始最晚的。
 * 返回 Map<commandId, segment>。
 */
export function desiredAt(segments, positionMs, leadMs = 0) {
  const probe = positionMs + leadMs;
  const active = new Map();
  for (const segment of segments) {
    if (probe < segment.startMs || probe >= segment.endMs) continue;
    const previous = active.get(segment.commandId);
    if (!previous || segment.startMs >= previous.startMs) {
      active.set(segment.commandId, segment);
    }
  }
  return active;
}

/** 比较前后两帧的激活集合，得到需要下发/停止的片段 */
export function diffActive(previous, next) {
  const started = [];
  const ended = [];
  for (const [key, segment] of next) {
    const before = previous.get(key);
    if (!before || before.id !== segment.id) started.push(segment);
  }
  for (const [key, segment] of previous) {
    const after = next.get(key);
    if (!after || after.id !== segment.id) ended.push(segment);
  }
  return { started, ended };
}

export function validateSegment(segment, durationMs) {
  if (!segment.commandId) return '请选择指令';
  if (!(segment.endMs > segment.startMs)) return '结束时间必须晚于开始时间';
  if (segment.startMs < 0) return '开始时间不能为负';
  if (durationMs > 0 && segment.endMs > durationMs) return '结束时间超出视频时长';
  if (segment.endMs - segment.startMs < 200) return '片段至少 0.2 秒';
  return null;
}

export function findOverlap(segments, candidate) {
  return (
    segments.find(
      (segment) =>
        segment.id !== candidate.id &&
        segment.commandId === candidate.commandId &&
        candidate.startMs < segment.endMs &&
        segment.startMs < candidate.endMs,
    ) ?? null
  );
}

export function formatTime(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  const mm = String(minutes).padStart(2, '0');
  const ss = String(seconds).padStart(2, '0');
  return hours > 0 ? `${hours}:${mm}:${ss}` : `${minutes}:${ss}`;
}

export function formatSeconds(ms) {
  return (ms / 1000).toFixed(1);
}
